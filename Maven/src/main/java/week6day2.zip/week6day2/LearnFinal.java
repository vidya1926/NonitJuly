package week6day2;

public class LearnFinal {

	static int var=100;
	final static int  n=50;//like a constant 	
	final static int x = 0;
	
	
	public static void main(String[] args) {
	
		System.out.println(var);
		LearnFinal obj=new LearnFinal();
		
			}

}
